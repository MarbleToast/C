#ifndef RANDNORM_H
#define RANDNORM_H

int randNorm(double mean, double sd);

unsigned int* randNumsToSum(unsigned int target, unsigned int steps);

#endif
