#!/bin/sh

gcc -ansi -pedantic -lm -o simQ Customer.c CustomerParser.c Queue.c RandNorm.c simQ.c